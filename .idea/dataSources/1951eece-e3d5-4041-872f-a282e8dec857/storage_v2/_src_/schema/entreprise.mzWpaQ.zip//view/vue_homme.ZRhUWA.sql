create view vue_homme as
select `entreprise`.`employes`.`prenom`  AS `prenom`,
       `entreprise`.`employes`.`nom`     AS `nom`,
       `entreprise`.`employes`.`sexe`    AS `sexe`,
       `entreprise`.`employes`.`service` AS `service`
from `entreprise`.`employes`
where `entreprise`.`employes`.`sexe` = 'm';

